if __name__ == '__main__':
    count = 0
    i = 5
    
    while i <= 10:
        count += 1
        print(f'{count = }, {i = }')
        i += 1
