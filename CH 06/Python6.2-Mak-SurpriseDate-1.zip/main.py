from date import Date

if __name__ == '__main__':
    date = Date(2025, 2, 4)  # February 4, 2025
    print(date)
    # print(str(date))
    # print(f'{date}')
    # print(f'{date = }')
