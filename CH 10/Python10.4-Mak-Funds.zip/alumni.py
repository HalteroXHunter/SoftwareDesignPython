class Alumni:
    def send_solicitations(self):
        print('Send solicitations to alumni.')
        