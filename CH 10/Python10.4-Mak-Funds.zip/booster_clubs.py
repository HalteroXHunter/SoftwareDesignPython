class BoosterClubs:
    def schedule_meetings(self):
        print('Schedule meetings with booster clubs.')
