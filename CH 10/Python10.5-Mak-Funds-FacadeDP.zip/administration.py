from fund_raiser import FundRaiser

class Administration:
    def aid_fundraising(self):
        print()
        print('SCHOOL ADMINISTRATION')
        
        fund_raiser = FundRaiser()
        fund_raiser.do_fund_raising()
