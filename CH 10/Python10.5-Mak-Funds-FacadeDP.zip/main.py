from athletics_dept import AthleticsDept
from administration import Administration

if __name__ == '__main__':
    athletics = AthleticsDept()
    athletics.raise_funds();
    
    administration = Administration()
    administration.aid_fundraising()
    