from fund_raiser import FundRaiser

class AthleticsDept:
    def raise_funds(self):
        print()
        print('ATHLETICS DEPARTMENT')
        
        fund_raiser = FundRaiser()
        fund_raiser.do_fund_raising()
