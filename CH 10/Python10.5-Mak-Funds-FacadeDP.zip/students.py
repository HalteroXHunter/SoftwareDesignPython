class Students:
    def collect_fees(self):
        print('Collect student fees.')
