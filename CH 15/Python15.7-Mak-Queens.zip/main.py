from queens import Queens

if __name__ == '__main__':
    q = Queens()
    q.find_solutions()
    
    print()
    print('Done!')
