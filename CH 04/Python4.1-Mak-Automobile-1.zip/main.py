from automobile import Automobile

if __name__ == '__main__':
    auto = Automobile()
    auto.accelerate()