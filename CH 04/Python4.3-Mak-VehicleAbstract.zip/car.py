from motorvehicle import MotorVehicle

class Car(MotorVehicle):
    def start_engine(self):
        print('car starts engine')
    
    def stop_engine(self):
        print('car stops engine')
