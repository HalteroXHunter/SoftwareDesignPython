from car import Car
from truck import Truck

if __name__ == '__main__':
    car = Car()
    car.drive()
    
    print()
    
    truck = Truck()
    truck.drive()