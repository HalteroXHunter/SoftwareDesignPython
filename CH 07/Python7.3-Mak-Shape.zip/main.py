from shape import Shape

if __name__ == '__main__':
    rectangle = Shape()
    print(f'{rectangle.area(2, 3) = }')
    
    circle = Shape()
    print(f'{circle.area(1.0) = :6.4f}')
