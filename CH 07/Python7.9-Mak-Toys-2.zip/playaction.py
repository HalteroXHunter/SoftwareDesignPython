class FlyPlay:
    
    @staticmethod
    def play(): return 'fly it'
    
class RollPlay:
    
    @staticmethod
    def play(): return 'roll it'
    