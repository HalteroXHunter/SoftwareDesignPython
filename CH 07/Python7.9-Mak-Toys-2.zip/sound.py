class EngineSound:
    
    @staticmethod
    def sound(): return 'RRrr RRrr'
    
class ChooChooSound:
    
    @staticmethod
    def sound(): return 'choo choo'
    