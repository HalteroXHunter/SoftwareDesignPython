from toy import ToyCar, ModelAirplane, TrainSet

if __name__ == '__main__':
    car = ToyCar()
    print(car)
    
    plane = ModelAirplane()
    print(plane)
    
    train = TrainSet()
    print(train)
