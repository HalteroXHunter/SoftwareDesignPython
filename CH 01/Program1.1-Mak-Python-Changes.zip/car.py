class Car:
    def step_on_brake(self):
        print("Stepped on the brake.")
        
    def insert_key(self):
        print("Inserted the key.")
        
    def turn_key(self):
        print("Turned the key.")
        
    def step_on_accelerator(self):
        print("Stepped on the accelerator.")