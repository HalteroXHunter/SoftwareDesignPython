from date import Date

if __name__ == '__main__':
    birthdate = Date(2025, 9, 2)  # SEP 2, 2025
    print(birthdate)