class Pet:
    def id(self):
        return ''
    
class Cat(Pet):
    def id(self):
        return 'cat'
    
class Dog(Pet):
    def id(self):
        return 'dog'