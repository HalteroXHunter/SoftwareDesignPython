from pet import Cat

if __name__ == '__main__':
    pet = Cat()
    print(f'My pet is a {pet.id()}.')