from baseball_reporter import BaseballReporter

if __name__ == '__main__':
    reporter = BaseballReporter()
    reporter.report_hits()
