from book import Book

class Fiction(Book):    
    def __init__(self, attrs):
        super().__init__(attrs)