from book import Book

class Cookbook(Book):  
    def __init__(self, attrs):
        super().__init__(attrs)