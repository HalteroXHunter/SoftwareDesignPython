from ticket_machine import TicketMachine

if __name__ == '__main__':
    machine = TicketMachine(3)
    machine.run()